// M?c d�ch: c?u h�nh filter to�n c?c cho pipeline MVC.
using System.Web.Mvc;

namespace HospitalQualityDashboardDemo
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
